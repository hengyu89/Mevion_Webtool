(function () {
  function parseRows(text) {
    const rows = [];
    let row = [];
    let field = "";
    let inQuotes = false;
    let index = text.charCodeAt(0) === 0xfeff ? 1 : 0;

    for (; index < text.length; index += 1) {
      const char = text[index];
      const next = text[index + 1];

      if (char === '"') {
        if (inQuotes && next === '"') {
          field += '"';
          index += 1;
        } else {
          inQuotes = !inQuotes;
        }
        continue;
      }

      if (char === "," && !inQuotes) {
        row.push(field);
        field = "";
        continue;
      }

      if ((char === "\n" || char === "\r") && !inQuotes) {
        if (char === "\r" && next === "\n") index += 1;
        row.push(field);
        rows.push(row);
        row = [];
        field = "";
        continue;
      }

      field += char;
    }

    if (field || row.length) {
      row.push(field);
      rows.push(row);
    }

    return rows;
  }

  // Rollover files keep the standard TCLogger column order but omit the header.
  // Return whether the first record is data so callers do not discard it.
  function resolveTcLogHeader(columns, requireSource = false) {
    const names = columns.map((value) => String(value || "").trim());
    const indexes = {
      timestamp: names.indexOf("TC Timestamp"),
      source: names.indexOf("Source"),
      message: names.indexOf("Message Text")
    };
    if (indexes.timestamp >= 0 && indexes.message >= 0 && (!requireSource || indexes.source >= 0)) {
      return { indexes, isData: false };
    }
    if (names.length >= 7 && /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?$/.test(names[0])) {
      return { indexes: { timestamp: 0, source: 2, message: 6 }, isData: true };
    }
    throw new Error("未找到有效的 TCLogger 表头或无表头日志记录。");
  }

  window.CsvUtils = { parseRows, resolveTcLogHeader };
})();
